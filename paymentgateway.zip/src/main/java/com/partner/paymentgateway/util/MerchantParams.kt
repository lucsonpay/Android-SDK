package com.partner.paymentgateway.util

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MerchantParams(
    var merAmount: String = "",
    var merPayId: String= "",
    var merCurrencyCode: String= "",
    var merCustEmail: String= "",
    var merCustName: String= "",
    var merCustPhone: String= "",
    var merCustAddress: String= "",
    var merCustZip: String= "",
    var merName: String= "",
    var merOrderId: String= "",
    var merProductDesc: String= "",
    var merTxnType: String= "",
    var merKey: String= "",
    var actionBarTitle: String= "",
    var actionBarColor: Int = 0,
    var isProductionEnv: Boolean=false,
    var responseUrl: String= "",
    var requestUrl: String= ""
) : Parcelable
