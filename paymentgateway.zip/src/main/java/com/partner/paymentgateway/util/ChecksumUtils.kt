package com.partner.paymentgateway.util

import org.apache.commons.codec.binary.Hex
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.*

class ChecksumUtils {

    private val stack: Stack<MessageDigest?> =Stack()
    private val separator = "~"
    private val equator = "="
    private val hashingAlgo = "SHA-256"

    fun ChecksumUtils() {}

    @Throws(NoSuchAlgorithmException::class)
    fun generateCheckSum(
        parameters: Map<String?, String?>?,
        secretKey: String?
    ): String {
        val treeMap: TreeMap<Any?, Any?> =
            TreeMap<Any?, Any?>(parameters)
        val allFields = StringBuilder()
        val var5: Iterator<*> = treeMap.keys.iterator()
        while (var5.hasNext()) {
            val key = var5.next() as String
            allFields.append("~")
            allFields.append(key)
            allFields.append("=")
            allFields.append(treeMap[key])
        }
        allFields.deleteCharAt(0)
        allFields.append(secretKey)
        return getHash(allFields.toString())
    }

    @Throws(NoSuchAlgorithmException::class)
    fun validateResponseChecksum(
        responseParameters: Map<String?, String?>?,
        secretKey: String?,
        responseHash: String
    ): Boolean {
        var flag = false
        val generatedHash = generateCheckSum(responseParameters, secretKey)
        if (generatedHash == responseHash) {
            flag = true
        }
        return flag
    }

    @Throws(NoSuchAlgorithmException::class)
    fun getHash(input: String): String {
        var response: String? = null
        val messageDigest = provide()
        messageDigest!!.update(input.toByteArray())
        consume(messageDigest)
        response = String(Hex.encodeHex(messageDigest.digest()))
        return response!!.toUpperCase()
    }

    @Throws(NoSuchAlgorithmException::class)
    private fun provide(): MessageDigest? {
        var digest: MessageDigest? = null
        digest = try {
            stack.pop()
        } catch (var2: EmptyStackException) {
            MessageDigest.getInstance("SHA-256")
        }
        return digest
    }

    private fun consume(digest: MessageDigest?) {
        stack.push(digest)
    }
}