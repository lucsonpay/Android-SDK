package com.partner.paymentgateway.util

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class GetResponseUrl(
    var responseurl: String,
    var requesturl: String
) : Parcelable