package com.partner.paymentgateway.util

import android.util.Log
import java.util.logging.Logger

class PayReqParams {
    val TAG = Logger.getLogger(PayReqParams::class.java.name).toString()
    private var merchantParams: MerchantParams? = null
    private val errorMessage = "Param not allowed to be null"

    fun PayReqParams() {}

    fun getMerchantParams(): MerchantParams? {
        return merchantParams
    }

    fun setMerchantParams(merchantParams: MerchantParams) {
        checkParams("MerchantParams :PayId", merchantParams.merPayId)
        checkParams("MerchantParams :Amount", merchantParams.merAmount)
        checkParams("MerchantParams :CurrencyCode", merchantParams.merCurrencyCode)
        checkParams("MerchantParams :ActionBarTitle", merchantParams.actionBarTitle)
        checkParams("MerchantParams :CustAddress", merchantParams.merCustAddress)
        checkParams("MerchantParams :Key", merchantParams.merKey)
        checkParams("MerchantParams :CustEmail", merchantParams.merCustEmail)
        checkParams("MerchantParams :CustName", merchantParams.merCustName)
        checkParams("MerchantParams :CustPhone", merchantParams.merCustPhone)
        checkParams("MerchantParams :CustZip", merchantParams.merCustZip)
        checkParams("MerchantParams :MerName", merchantParams.merName)
        checkParams("MerchantParams :OrderId", merchantParams.merOrderId)
        checkParams("MerchantParams :ProdDesc", merchantParams.merProductDesc)
        checkParams("MerchantParams :TxnType", merchantParams.merTxnType)
        checkParams("MerchantParams :MerchantRequest", merchantParams.requestUrl)
        checkParams("MerchantParams :MerchantResponse", merchantParams.responseUrl)
        Log.d(TAG,"####Merchant Params  $merchantParams")
        this.merchantParams = merchantParams
    }

    private fun checkParams(reference: String, params: String) {
        if (AppUtil.isBlank(params)) {
            throw NullPointerException("$reference : $errorMessage")
        }
    }
}