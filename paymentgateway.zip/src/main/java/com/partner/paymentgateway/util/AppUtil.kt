package com.partner.paymentgateway.util

import android.content.Context
import android.net.ConnectivityManager
import androidx.annotation.Nullable
import java.util.regex.Pattern

class AppUtil {
    companion object {
        val PG_PAY_REQ = "pg_pay_req"
        val PG_RESULT = "pg_result"
        val PG_MESSAGE = "pg_message"
        val PG_CANCEL_CODE = "pg_cancel_code"
        val PG_REQ_CODE = 1011
        var msg_cancel_txn = "Transaction canceled by user!"
        var network_error = "NO INTERNET CONNECTIVITY"
        var msg_null_intent ="Intent should not null, its must be  contain object of PayReqParams  with pg_pay_req key "
        var PG_URL = "https://uat.starpayindia.com/starpay/jsp/paymentrequest"
        var RETURN_URL = "https://uat.starpayindia.com/starpayindia/jsp/sdkResponse.jsp"

        fun <T> checkNotNull(reference: T?, @Nullable errorMessage: Any): T {
            return reference ?: throw NullPointerException(errorMessage.toString())
        }

        fun isBlank(cs: String?): Boolean {
            return cs == null || cs.trim { it <= ' ' }.isEmpty() || cs.trim { it <= ' ' } === "null"
        }

        fun isNetworkAvailable(context: Context): Boolean {
            var haveConnectedWifi = false
            var haveConnectedMobile = false
            val cm =
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeInfo = cm.activeNetworkInfo
            if (activeInfo != null && activeInfo.isConnected) {
                haveConnectedWifi = activeInfo.type == 1
                haveConnectedMobile = activeInfo.type == 0
            }
            return haveConnectedWifi || haveConnectedMobile
        }

        fun getVerificationCode(message: String?): String? {
            var code: String? = null
            return try {
                val pattern =
                    Pattern.compile("(^|\\W)\\d{6,8}($|\\W)")
                val matcher = pattern.matcher(message)
                for (i in 0 until matcher.groupCount()) {
                    matcher.find()
                    code = matcher.group().replace("\\D+".toRegex(), "")
                    if (code != null && (code.length == 6 || code.length == 8)) {
                        return code
                    }
                    code = null
                }
                code
            } catch (var5: Exception) {
                var5.printStackTrace()
                null
            }
        }
    }
}