package com.partner.paymentgateway.util

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class PayResParams (
    var RESPONSE_DATE_TIME: String? = null,
    var STATUS: String? = null,
    var AMOUNT: String? = null,
    var CUST_EMAIL: String? = null,
    var TXNTYPE: String? = null,
    var HASH: String? = null,
    var PAYMENT_TYPE: String? = null,
    var RESPONSE_CODE: String? = null,
    var CUST_PHONE: String? = null,
    var CURRENCY_CODE: String? = null,
    var PRODUCT_DESC: String? = null,
    var RESPONSE_MESSAGE: String? = null,
    var TXN_ID: String? = null,
    var RETURN_URL: String? = null,
    var PAY_ID: String? = null,
    var ORDER_ID: String? = null,
    var CUST_NAME: String? = null
) : Parcelable