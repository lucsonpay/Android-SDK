package com.partner.paymentgateway.sdk

import android.app.Activity
import androidx.fragment.app.Fragment
import com.partner.paymentgateway.util.PayReqParams

object PaySdkInt {

    fun getInstance(act: Activity?, payReqParams: PayReqParams?): PaySdkInt? {
        val plutusPG: PaySdkPG = PaySdkPG.getInstance(payReqParams!!)
        plutusPG.initiatePG(act!!)
        return this
    }
    fun getInstance(frag: Fragment?, payReqParams: PayReqParams?): PaySdkInt? {
        val plutusPG: PaySdkPG = PaySdkPG.getInstance(payReqParams!!)
        plutusPG.initiatePG(frag!!)
        return this
    }
}