package com.partner.paymentgateway.sdk

import android.app.Activity
import android.content.Intent
import androidx.fragment.app.Fragment
import com.partner.paymentgateway.util.*
import org.json.JSONObject
import java.util.*

class PaySdkPG {

    private val TAG = "PaySdkPG==>"
    private var requestparameter: String? = null
    private var pgData: String? = null
    private var decrypt: String? = null
    private var actionTitle: String? = null
    private var actionColor = 0
companion object {
    fun getInstance(payReq: PayReqParams): PaySdkPG {
        return PaySdkPG().PaySdkPG(payReq)
    }
}

    private fun PaySdkPG(pay: PayReqParams) :PaySdkPG {
        val merchant: MerchantParams? = pay.getMerchantParams()
        if (merchant == null) {
            throwExp(TAG, "You should be provide valid object of MerchantParams")
        }
        AppUtil.PG_URL = merchant!!.requestUrl
        AppUtil.RETURN_URL = merchant.responseUrl

        requestparameter = getRequestParameter(merchant, merchant.merKey)
        decrypt = merchant.merKey
        actionTitle = merchant.actionBarTitle
        actionColor = merchant.actionBarColor
        if (requestparameter != null && !requestparameter.equals("", ignoreCase = true)) {
            try {
                pgData = requestparameter
            } catch (var4: Exception) {
                var4.printStackTrace()
            }
        } else {
            throwExp(TAG, "You should be provide valid object of requestparameter")
        }
        return this
    }

    fun initiatePG(activity: Activity) {

        if (pgData == null) {
            throwExp( TAG,"initialising data must be not null. You must provide valid object of PayReqParams")
        } else {
            val i = Intent(activity.applicationContext, PGScreen::class.java)
            i.putExtra("pg_pay_req", pgData)
            i.putExtra("title", actionTitle)
            i.putExtra("color", actionColor)
            activity.startActivityForResult(i, AppUtil.PG_REQ_CODE)
        }
    }
    fun initiatePG(fragment: Fragment) {

        if (pgData == null) {
            throwExp( TAG,"initialising data must be not null. You must provide valid object of PayReqParams")
        } else {
            val i = Intent(fragment.context, PGScreen::class.java)
            i.putExtra("pg_pay_req", pgData)
            i.putExtra("title", actionTitle)
            i.putExtra("color", actionColor)
            fragment.startActivityForResult(i, AppUtil.PG_REQ_CODE)
        }
    }
    private fun getRequestParameter(mer: MerchantParams?, Key: String): String? {
        return try {
            val map: MutableMap<String?, String?> = HashMap()
            map["AMOUNT"] = mer?.merAmount
            map["CURRENCY_CODE"] = mer?.merCurrencyCode
            map["CUST_EMAIL"] = mer?.merCustEmail
            map["CUST_NAME"] = mer?.merCustName
            map["CUST_PHONE"] = mer?.merCustPhone
            map["CUST_STREET_ADDRESS1"] = mer?.merCustAddress
            map["CUST_ZIP"] = mer?.merCustZip
            map["MERCHANTNAME"] = mer?.merName
            map["ORDER_ID"] = mer?.merOrderId
            map["PAY_ID"] = mer?.merPayId
            map["PRODUCT_DESC"] = mer?.merProductDesc
            map["RETURN_URL"] = AppUtil.RETURN_URL
            map["TXNTYPE"] = mer?.merTxnType
            map["App_Model"] ="1.0.1"
            val hash: String = ChecksumUtils().generateCheckSum(map, mer?.merKey)
            map["HASH"] = hash
            val separator = "&"
            val keyValueSeparator = "="
            val buffer = StringBuffer()
            val entryIterator: Iterator<*> = map.entries.iterator()
            while (entryIterator.hasNext()) {
                val entry: Map.Entry<*, *> = entryIterator.next() as Map.Entry<*, *>
                buffer.append(entry.key)
                buffer.append(keyValueSeparator)
                buffer.append(entry.value)
                if (entryIterator.hasNext()) {
                    buffer.append(separator)
                }
            }
            buffer.toString()
        } catch (var10: Exception) {
            var10.printStackTrace()
            ""
        }
    }

    private fun PaySdkPG() {}

    private fun concatParams(key: String, value: String): String? {
        return "$key=$value&"
    }

    private fun throwExp(reference: String, errorMessage: String) {
        throw NullPointerException("$reference:$errorMessage")
    }

    fun getPlutusResponse(res: String?): PayResParams? {
        val resParams = PayResParams()
        try {
            val `object` = JSONObject(res)
            resParams.RESPONSE_DATE_TIME =(`object`.getString("RESPONSE_DATE_TIME"))
            resParams.STATUS=(`object`.getString("STATUS"))
            resParams.AMOUNT=(`object`.getString("AMOUNT"))
            resParams.CUST_EMAIL= (`object`.getString("CUST_EMAIL"))
            resParams.TXNTYPE=(`object`.getString("TXNTYPE"))
            resParams.HASH=(`object`.getString("HASH"))
            resParams.PAYMENT_TYPE=(`object`.getString("PAYMENT_TYPE"))
            resParams.RESPONSE_CODE=(`object`.getString("RESPONSE_CODE"))
            resParams.CURRENCY_CODE=(`object`.getString("CURRENCY_CODE"))
            resParams.PRODUCT_DESC=(`object`.getString("PRODUCT_DESC"))
            resParams.RESPONSE_MESSAGE=(`object`.getString("RESPONSE_MESSAGE"))
            resParams.TXN_ID=(`object`.getString("TXN_ID"))
            resParams.RETURN_URL=(`object`.getString("RETURN_URL"))
            resParams.PAY_ID=(`object`.getString("PAY_ID"))
            resParams.ORDER_ID=(`object`.getString("ORDER_ID"))
            resParams.CUST_NAME=(`object`.getString("CUST_NAME"))
        } catch (var3: Exception) {
            var3.printStackTrace()
        }
        return resParams
    }
}