package com.partner.paymentgateway.sdk

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.net.http.SslError
import android.os.Build.VERSION
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.*
import android.webkit.WebSettings.RenderPriority
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar
import com.partner.paymentgateway.R
import com.partner.paymentgateway.util.AppUtil
import com.partner.paymentgateway.util.PayResParams
import kotlinx.android.synthetic.main.webview_content.*

class PGScreen : AppCompatActivity(){
    private val TAG: String = PGScreen::class.java.name
    var mWebView: WebView? = null
    private val mHandler: Handler? = null
    private val pg_amount: String? = null
    private val exit = false
    private val pro_bar: ProgressBar? = null
    private val snackbar: Snackbar? = null
    private val txnFor = "wallet"
    private val txnId = ""
    private var progressBar: ProgressBar? = null
    private var cancelTransaction = false
    private val MENU_CANCEL = 1


    protected override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(null as Bundle?)
        if (savedInstanceState != null) {
            this.finish()
        }
        this.setContentView(R.layout.webview_content)
        mWebView = this.findViewById(R.id.webview_pay) as WebView?
        progressBar = this.findViewById(R.id.progressBar) as ProgressBar?
        mWebView!!.settings.javaScriptEnabled = true
        mWebView!!.addJavascriptInterface(PayJavaScriptInterface(), "Android")
        mWebView!!.settings.domStorageEnabled = true
        mWebView!!.settings.setSupportMultipleWindows(true)
        mWebView!!.settings.javaScriptCanOpenWindowsAutomatically = true
        mWebView!!.settings.setRenderPriority(RenderPriority.HIGH)
        mWebView!!.settings.cacheMode =WebSettings.LOAD_NO_CACHE
        mWebView!!.clearCache(true)
        mWebView!!.clearHistory()
        if (VERSION.SDK_INT >= 19) {
            val var10001: ApplicationInfo = this.applicationInfo
            if (0 != 2.let { var10001.flags = var10001.flags and it; var10001.flags }) {
                val var10000 = mWebView
                WebView.setWebContentsDebuggingEnabled(true)
            }
        }
        mWebView!!.setWebChromeClient(object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                return super.onConsoleMessage(consoleMessage)
            }
        })
        mWebView!!.webViewClient = object : WebViewClient() {
            override fun onPageStarted(
                view: WebView,
                url: String,
                favicon: Bitmap?
            ) {
                progressBar!!.visibility = View.VISIBLE
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(view: WebView, url: String) {
                progressBar!!.visibility = View.INVISIBLE
                super.onPageFinished(view, url)
            }

            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return super.shouldOverrideUrlLoading(view, url)
            }

            override fun shouldOverrideKeyEvent(
                view: WebView,
                event: KeyEvent
            ): Boolean {
                return super.shouldOverrideKeyEvent(view, event)
            }

            override fun onReceivedSslError(
                view: WebView,
                handler: SslErrorHandler,
                error: SslError
            ) {
                try {
                    val builder =
                        AlertDialog.Builder(this@PGScreen)
                    builder.setMessage("SSL Certificate seems invalid. Do you want to continue ?")
                    builder.setPositiveButton(
                        "continue"
                    ) { dialog, which -> handler.proceed() }
                    builder.setNegativeButton(
                        "cancel"
                    ) { dialog, which -> handler.cancel() }
                    val dialog = builder.create()
                    dialog.show()
                } catch (var6: Exception) {
                    var6.printStackTrace()
                }
            }

            @SuppressLint("NewApi")
            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)
            }
        }
        init()
    }

    private fun init() {
        try {
            if (this.intent == null || this.intent.extras == null) {
                Log.i(TAG, AppUtil.msg_null_intent)
                onCancel(AppUtil.msg_null_intent)
                return
            }
            val b: Bundle? = this.intent.extras
            val pgData = b?.getString("pg_pay_req")
            if (this.supportActionBar != null) {
                this.supportActionBar!!.setTitle(
                    if (b?.getString("title") == null) java.lang.String.valueOf(this.title) else b.getString(
                        "title"
                    )
                )
                this.supportActionBar!!.setBackgroundDrawable(
                    ContextCompat.getDrawable(
                        this,
                        if (b?.getInt("color") == 0) R.color.snackbarBankOTPbg else b?.getInt("color")!!
                    )
                )
            }
            if (pgData != null) {
                try {
                    if (!AppUtil.isNetworkAvailable(this)) {
                        onCancel(AppUtil.network_error)
                    }
                    if (AppUtil.PG_URL != null) {
                        mWebView!!.postUrl(
                            AppUtil.PG_URL,
                            pgData.toByteArray(charset("UTF-8"))
                        )
                    }
                } catch (var4: Exception) {
                    var4.printStackTrace()
                }
            } else {
                throwExp(TAG, "You should be provide valid object of MerchantParams")
            }
        } catch (var5: Exception) {
            var5.printStackTrace()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.clear()
        menu.add(0, 1, 0, "Cancel Txn.").setShowAsAction(0)
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return if (id == 1) {
            onCancel(AppUtil.msg_cancel_txn)
            true
        } else {
            super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        try {
            if (cancelTransaction) {
                cancelTransaction = false
                onCancel(AppUtil.msg_cancel_txn)
                return
            }
            val alertDialog = AlertDialog.Builder(this)
            alertDialog.setCancelable(false)
            alertDialog.setMessage("Do you really want to cancel the transaction ?")
            alertDialog.setPositiveButton(
                "Yes"
            ) { dialog, which ->
                cancelTransaction = true
                dialog.dismiss()
                onBackPressed()
            }
            alertDialog.setNegativeButton(
                "No"
            ) { dialog, which -> dialog.dismiss() }
            alertDialog.show()
        } catch (var2: Exception) {
            var2.printStackTrace()
            super.onBackPressed()
        }
    }

    private fun onCancel(msg: String) {
        try {
            val intent = Intent()
            intent.putExtra("pg_result", PayResParams())
            intent.putExtra("pg_message", msg)
            intent.putExtra("pg_cancel_code", 2)
            this.setResult(0, intent)
            if (mWebView != null) {
                mWebView!!.removeAllViews()
                mWebView!!.destroy()
            }
            this.finish()
        } catch (var3: Exception) {
            var3.printStackTrace()
            this.finish()
        }
    }

    private fun throwExp(reference: String, errorMessage: String) {
        throw NullPointerException("$reference:$errorMessage")
    }

  inner  class PayJavaScriptInterface internal constructor() {
        @JavascriptInterface
        fun process(resparam: String?) {
            super@PGScreen.runOnUiThread(Runnable {
                val intent = Intent()
                val plutusResponse: PayResParams? = PaySdkPG().getPlutusResponse(resparam)
                println(resparam)
                intent.putExtra("pg_result", plutusResponse)
                if (plutusResponse != null && plutusResponse.RESPONSE_MESSAGE != null) {
                    intent.putExtra("pg_message", plutusResponse.RESPONSE_MESSAGE)
                } else {
                    intent.putExtra("pg_message", "Please contact customer care.")
                }
                if (plutusResponse?.RESPONSE_CODE != null && plutusResponse.RESPONSE_CODE.equals("000",true)) {
                    this@PGScreen.setResult(-1, intent)
                } else {
                    intent.putExtra("pg_cancel_code", 1)
                    this@PGScreen.setResult(0, intent)
                }
                if (this@PGScreen.mWebView != null) {
                    this@PGScreen.mWebView!!.removeAllViews()
                    this@PGScreen.mWebView!!.destroy()
                }
                this@PGScreen.finish()
            })
        }
    }
}